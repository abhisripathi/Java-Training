package com.code.demo;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.code.entity.Course;
import com.code.entity.Instructor;
import com.code.entity.InstructorProfile;
import com.code.entity.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
  SessionFactory sessionFactory=   	new Configuration().configure("hibernate.cfg.xml")
    						.addAnnotatedClass(Instructor.class)
    						.addAnnotatedClass(InstructorProfile.class)
    						.addAnnotatedClass(Course.class)
    						.addAnnotatedClass(Student.class)
    						.buildSessionFactory();
  //new CreateInstructor(sessionFactory);
 new ReadInstructor(sessionFactory);
  //new UpdateInstructor(sessionFactory);
  //new DeleteInstructor(sessionFactory);
    }
}
