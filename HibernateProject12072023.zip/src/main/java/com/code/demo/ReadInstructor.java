package com.code.demo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.code.entity.Instructor;
import com.code.entity.InstructorProfile;

public class ReadInstructor {
	SessionFactory sessionFactory;
	public ReadInstructor(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
		//session object
		Session session=sessionFactory.getCurrentSession();
		//start the transaction
		session.beginTransaction();
		//Get all the object from the table
		
		List<InstructorProfile> instructorProfiles=session.createQuery("from InstructorProfile").getResultList();
		
		for(InstructorProfile instructorProfile:instructorProfiles)
		{
			System.out.println(instructorProfile.toString());
		}
		
		
		
	}

}
