package com.code.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="course")
public class Course {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="courseid")
	private int courseid;
	@Column(name="title", nullable=false,length=50)
	private String title;
	@Column(name="fees")
	private double fees;
	@Column(name="duration", nullable=false,length=30)
	private String duration;
	@ManyToOne
	@JoinColumn(name="instructorid")
	private Instructor instructor;
	public Course()
	{
		
	}
	public Course(String title, double fees, String duration, Instructor instructor) {
		super();
		this.title = title;
		this.fees = fees;
		this.duration = duration;
		this.instructor = instructor;
	}
	public int getCourseid() {
		return courseid;
	}
	public void setCourseid(int courseid) {
		this.courseid = courseid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	
	
	public Instructor getInstructor() {
		return instructor;
	}
	public void setInstructor(Instructor instructor) {
		this.instructor = instructor;
	}
	@Override
	public String toString() {
		return "Course [courseid=" + courseid + ", title=" + title + ", fees=" + fees + ", duration=" + duration
				+ ", instructor=" + instructor + "]";
	}
	
	
}
