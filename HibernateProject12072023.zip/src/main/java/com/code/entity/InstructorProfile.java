package com.code.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="instructorprofile")
public class InstructorProfile {
	//create the member variable
		//mapped each member variable to the column
		//create one primary key
		//generate the pk value auto
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	@Column(name="qualiication",length=50)
	private String qualification;
	@Column(name="hobby",length=50)
	private String hobby;
	//create relationship onetoone with the Instructor
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="instructor_id")
	private Instructor instructor;
	
	
	public InstructorProfile()
	{
		this.id=0;
		this.hobby=null;
		this.qualification=null;
		this.instructor=null;
	}


	public InstructorProfile(String qualification, String hobby, Instructor instructor) {
		super();
		this.qualification = qualification;
		this.hobby = hobby;
		this.instructor = instructor;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getQualification() {
		return qualification;
	}


	public void setQualification(String qualification) {
		this.qualification = qualification;
	}


	public String getHobby() {
		return hobby;
	}


	public void setHobby(String hobby) {
		this.hobby = hobby;
	}


	public Instructor getInstructor() {
		return instructor;
	}


	public void setInstructor(Instructor instructor) {
		this.instructor = instructor;
	}


	@Override
	public String toString() {
		return "InstructorProfile [id=" + id + ", qualification=" + qualification + ", hobby=" + hobby + ", instructor="
				+ instructor + "]";
	}
	
	
}
