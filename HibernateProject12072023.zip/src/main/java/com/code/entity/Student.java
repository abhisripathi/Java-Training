package com.code.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="student")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	@Column(name="fname",nullable=false,length=30)
	private String fname;
	@Column(name="lname",nullable=false,length=30)
	private String lname;
	@Column(name="emailid",nullable=false,length=30)
	private String emailid;
	//create MANYtoMany with course
	@ManyToMany
	@JoinTable(name="student_course",joinColumns=@JoinColumn(name="studentid"),inverseJoinColumns=@JoinColumn(name="courseid"))
	private List<Course> courses;
	public Student()
	{
		this.courses=null;
		this.emailid=null;
		this.fname=null;
		this.id=0;
		this.lname=null;

	}
	public Student(String fname, String lname, String emailid) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.emailid = emailid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public List<Course> getCourses() {
		return courses;
	}
	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

	public void addCourse(Course course)
	{
		if(courses==null)
		{
			courses=new ArrayList<Course>();
		}
		//add the course to the list
		courses.add(course);
	}
	
}
