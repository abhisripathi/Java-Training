package com.code.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="instructor")
public class Instructor {
	
	//create the member variable
	//mapped each member variable to the column
	//create one primary key
	//generate the pk value auto
	
	@Id //it will be PK
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	@Column(name="first_name",nullable=false,length=30)
	private String fname;
	@Column(name="last_name",nullable=false,length=30)
	private String lname;
	@Column(name="email_id",nullable=false,length=50)
	private String email;
	//create default constructor
	public Instructor()
	{
		this.id=0;
		this.fname=null;
		this.lname=null;
		this.email=null;
	}
	
	public Instructor(String fname, String lname, String email) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.email = email;
	}

	//generate the Getter and the Setter method
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	//we create a method toString
	@Override
	public String toString() {
		return "Instructor [id=" + id + ", fname=" + fname + ", lname=" + lname + ", email=" + email + "]";
	}
	

}
