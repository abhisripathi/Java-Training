package com.code.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.code.entity.Instructor;
import com.code.entity.InstructorProfile;

public class CreateInstructor {
	SessionFactory sessionFactory;
	public CreateInstructor(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
		//session object
		Session session=sessionFactory.getCurrentSession();
		//start the transaction
		session.beginTransaction();
		//create the object o the Instructor and InstructorProfile
		Instructor instructor=new Instructor("test1","Test Last1","test1@abc.com");
		InstructorProfile instructorProfile=new InstructorProfile("M-Tech", "Reading Books", instructor);
		
		//save the object
		session.save(instructorProfile);
		
		instructor=new Instructor("test2","Test2 Last","test2@abc.com");
		 instructorProfile=new InstructorProfile("M-Tech", "Reading Books", instructor);
		 session.save(instructorProfile);
	 instructor=new Instructor("test3","Test3 Last","test3@abc.com");
			 instructorProfile=new InstructorProfile("M-Tech", "Reading Books", instructor);
			 session.save(instructorProfile);
		//commit
		session.getTransaction().commit();
		System.out.println("Instructor is created successfully with ID "+instructor.getId());
		
		
	}

}
