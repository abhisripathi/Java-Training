package com.code.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.grammars.hql.HqlParser.IsNullPredicateContext;

import com.code.entity.Instructor;
import com.code.entity.InstructorProfile;

public class UpdateInstructor {
	SessionFactory sessionFactory;
	public UpdateInstructor(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
		//session object
		Session session=sessionFactory.getCurrentSession();
		//start the transaction
		session.beginTransaction();
		//set the id to update
		int instructorid=3;
		//get the object of the instructor with id 3
		InstructorProfile instructorProfile=session.get(InstructorProfile.class, instructorid);
		if(instructorProfile==null)
		{
			System.out.println("Instructor with id "+instructorid+" not found");
			return;
		}
		//print the old value
		System.out.println(instructorProfile.toString());
		//set the new value
		instructorProfile.getInstructor().setFname("Manoj");
		instructorProfile.getInstructor().setLname("Janapala");
		
		
		//update the object
		//saverupdate create the new record i id is null or 0
		//update the record of the id>0 or
		session.saveOrUpdate(instructorProfile);
		
		
		//commit
		session.getTransaction().commit();
		System.out.println("Instructor is updated successfully with ID "+instructorProfile.getId());
		
		
	}

}
